// Пересчет суммы по строкам и итога на странице.
// (Сохранение количества в базе делается только после нажатия "Обновить")

function formatMoney(n) {
    // Без сложных локалей, просто 2 знака
    return (Math.round(n * 100) / 100).toFixed(2);
}

function recalc() {
    const cards = document.querySelectorAll(".card");
    let total = 0;

    cards.forEach(card => {
        const unitEl = card.querySelector(".unitPrice");
        const qtyEl = card.querySelector(".qtyInput");
        const lineEl = card.querySelector(".lineTotal");

        if (!unitEl || !qtyEl || !lineEl) return;

        const unit = parseFloat(unitEl.textContent || "0");
        const qty = parseInt(qtyEl.value || "0", 10);

        const line = unit * qty;
        lineEl.textContent = formatMoney(line);
        total += line;
    });

    const totalEl = document.getElementById("cartTotal");
    if (totalEl) totalEl.textContent = formatMoney(total);
}

document.addEventListener("input", (e) => {
    if (e.target && e.target.classList.contains("qtyInput")) {
        recalc();
    }
});

document.addEventListener("DOMContentLoaded", () => recalc());