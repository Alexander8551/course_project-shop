-- Пароль везде "password"
-- BCrypt hash для слова "password"
-- (одинаковый для обоих пользователей, так проще для курсовой)
INSERT INTO users (id, username, password, role) VALUES
(1, 'admin', '$2a$10$voczES.rOP7osQgzjWqMBeRfS9l0uw1tmzJ9CpN3AnVxZ6AX/XDT6', 'ROLE_ADMIN'),
(2, 'user',  '$2a$10$voczES.rOP7osQgzjWqMBeRfS9l0uw1tmzJ9CpN3AnVxZ6AX/XDT6', 'ROLE_CUSTOMER');

-- Сдвигаем автоинкремент, чтобы новые пользователи (если появятся) не конфликтовали по id
ALTER TABLE users ALTER COLUMN id RESTART WITH 3;

INSERT INTO products (id, name, description, price, image_url) VALUES
(1, 'Клавиатура', 'Обычная проводная клавиатура. Ничего лишнего.', 1999.00, ''),
(2, 'Мышь', 'Компактная мышь для работы и учебы.', 999.00, ''),
(3, 'Наушники', 'Простые наушники, подходят для звонков.', 1499.00, ''),
(4, 'Флешка 32GB', 'USB флешка на 32GB.', 799.00, '');

-- Сдвигаем автоинкремент, чтобы новые товары создавались с id=5,6,7...
ALTER TABLE products ALTER COLUMN id RESTART WITH 5;