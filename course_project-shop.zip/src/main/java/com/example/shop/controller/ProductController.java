package com.example.shop.controller;

import com.example.shop.model.Product;
import com.example.shop.service.CartService;
import com.example.shop.service.ProductService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

// Просмотр товаров покупателем
@Controller
public class ProductController {

    private final ProductService productService;
    private final CartService cartService;

    public ProductController(ProductService productService, CartService cartService) {
        this.productService = productService;
        this.cartService = cartService;
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/products";
    }

    @GetMapping("/products")
    public String products(@RequestParam(required = false) String q,
                           @RequestParam(required = false) BigDecimal min,
                           @RequestParam(required = false) BigDecimal max,
                           Model model) {

        List<Product> products = productService.search(q, min, max);

        model.addAttribute("products", products);
        model.addAttribute("q", q);
        model.addAttribute("min", min);
        model.addAttribute("max", max);

        return "products";
    }

    @GetMapping("/products/{id}")
    public String product(@PathVariable Long id, Model model) {
        model.addAttribute("product", productService.getById(id));
        return "product";
    }

    @PostMapping("/products/{id}/add")
    public String addToCart(@PathVariable Long id,
                            @AuthenticationPrincipal UserDetails userDetails) {
        cartService.addToCart(userDetails.getUsername(), id);
        return "redirect:/cart";
    }
}