package com.example.shop.controller;

import com.example.shop.model.CartItem;
import com.example.shop.service.CartService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

// Корзина
@Controller
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping("/cart")
    public String cart(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        List<CartItem> items = cartService.getCart(userDetails.getUsername());
        BigDecimal total = cartService.calcTotal(items);

        model.addAttribute("items", items);
        model.addAttribute("total", total);
        return "cart";
    }

    @PostMapping("/cart/update")
    public String update(@AuthenticationPrincipal UserDetails userDetails,
                         @RequestParam Long id,
                         @RequestParam int quantity) {
        cartService.updateQuantity(userDetails.getUsername(), id, quantity);
        return "redirect:/cart";
    }

    @PostMapping("/cart/remove")
    public String remove(@AuthenticationPrincipal UserDetails userDetails,
                         @RequestParam Long id) {
        cartService.removeItem(userDetails.getUsername(), id);
        return "redirect:/cart";
    }

    @PostMapping("/cart/clear")
    public String clear(@AuthenticationPrincipal UserDetails userDetails) {
        cartService.clearCart(userDetails.getUsername());
        return "redirect:/cart";
    }
}