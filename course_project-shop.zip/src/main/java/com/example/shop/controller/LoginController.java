package com.example.shop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

// Страница логина
@Controller
public class LoginController {

    @GetMapping("/login")
    public String login() {
        return "login";
    }
}