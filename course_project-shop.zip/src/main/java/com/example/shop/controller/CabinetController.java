package com.example.shop.controller;

import com.example.shop.model.User;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

// Личный кабинет
@Controller
public class CabinetController {

    @GetMapping("/cabinet")
    public String cabinet(@AuthenticationPrincipal User user, Model model) {
        // user тут уже из Security (это entity, потому что implements UserDetails)
        model.addAttribute("username", user.getUsername());
        model.addAttribute("role", user.getRole());
        return "cabinet";
    }
}