package com.example.shop.repository;

import com.example.shop.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

// Работа с товарами
public interface ProductRepository extends JpaRepository<Product, Long> {

    // Простой поиск/фильтр по названию и цене (если параметр null - не фильтруем)
    @Query("""
        select p from Product p
        where (:q is null or :q = '' or lower(p.name) like lower(concat('%', :q, '%')))
          and (:min is null or p.price >= :min)
          and (:max is null or p.price <= :max)
        order by p.id desc
    """)
    List<Product> search(@Param("q") String q,
                         @Param("min") BigDecimal min,
                         @Param("max") BigDecimal max);
}