package com.example.shop.repository;

import com.example.shop.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

// Работа с таблицей пользователей
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
}