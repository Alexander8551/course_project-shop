package com.example.shop.service;

import com.example.shop.model.CartItem;
import com.example.shop.model.Product;
import com.example.shop.model.User;
import com.example.shop.repository.CartItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

// Логика корзины
@Service
public class CartService {

    private final CartItemRepository cartItemRepository;
    private final UserService userService;
    private final ProductService productService;

    public CartService(CartItemRepository cartItemRepository, UserService userService, ProductService productService) {
        this.cartItemRepository = cartItemRepository;
        this.userService = userService;
        this.productService = productService;
    }

    public List<CartItem> getCart(String username) {
        User user = userService.getByUsername(username);
        return cartItemRepository.findByUserOrderByIdDesc(user);
    }

    @Transactional
    public void addToCart(String username, Long productId) {
        User user = userService.getByUsername(username);
        Product product = productService.getById(productId);

        CartItem item = cartItemRepository.findByUserAndProduct(user, product).orElse(null);
        if (item == null) {
            item = new CartItem(user, product, 1);
        } else {
            item.setQuantity(item.getQuantity() + 1);
        }

        cartItemRepository.save(item);
    }

    @Transactional
    public void updateQuantity(String username, Long cartItemId, int quantity) {
        // Простая защита от странных значений
        if (quantity < 1) {
            quantity = 1;
        }

        User user = userService.getByUsername(username);
        CartItem item = cartItemRepository.findById(cartItemId)
            .orElseThrow(() -> new IllegalArgumentException("Позиция корзины не найдена: " + cartItemId));

        // Проверяем, что пользователь меняет только свою корзину
        if (!item.getUser().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Нельзя менять чужую корзину");
        }

        item.setQuantity(quantity);
        cartItemRepository.save(item);
    }

    @Transactional
    public void removeItem(String username, Long cartItemId) {
        User user = userService.getByUsername(username);
        CartItem item = cartItemRepository.findById(cartItemId)
            .orElseThrow(() -> new IllegalArgumentException("Позиция корзины не найдена: " + cartItemId));

        if (!item.getUser().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Нельзя удалять из чужой корзины");
        }

        cartItemRepository.delete(item);
    }

    @Transactional
    public void clearCart(String username) {
        User user = userService.getByUsername(username);
        cartItemRepository.deleteByUser(user);
    }

    public BigDecimal calcTotal(List<CartItem> items) {
        BigDecimal total = BigDecimal.ZERO;
        for (CartItem item : items) {
            BigDecimal line = item.getProduct().getPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
            total = total.add(line);
        }
        return total;
    }
}