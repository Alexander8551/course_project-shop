package com.example.shop.model;

import jakarta.persistence.*;

// Позиция в корзине (какой товар и сколько)
@Entity
@Table(name = "cart_items",
       uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "product_id"}))
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Чей это товар в корзине
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private User user;

    // Какой товар
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Product product;

    // Сколько штук
    @Column(nullable = false)
    private int quantity;

    public CartItem() {
    }

    public CartItem(User user, Product product, int quantity) {
        this.user = user;
        this.product = product;
        this.quantity = quantity;
    }

    public Long getId() {
        return id;
    }

    public User getUser() {
        return user;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}